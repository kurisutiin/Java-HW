package pkgcom.cognizant.shapes;

public class Shapes{

	
		private int numberOfSides;
		
		
		
		
		public int getNumberOfSides() {
			return numberOfSides;
		}
		public void setNumberOfSides(int numberOfSides) {
			this.numberOfSides = numberOfSides;
		}
		
		
		public void calculateShapeArea (int shape, int sidelength) {
			
			
			if(this.numberOfSides == 1) {
				Circle c = new Circle();
				c.calculateArea(sidelength);
				//System.out.println("The Area of the Circle is " + numberOfSides);
			}
				else if (numberOfSides == 3) {
					Triangle t = new Triangle();
					t.calculateArea(sidelength);
					//System.out.println("The Area of the Triangle is ");
					
				}
				else if (numberOfSides == 4) {
					
					Square s = new Square();
					s.calculateArea(sidelength);
					//System.out.print("The Area of the Square is ");
				}
					else {
						System.out.print("No Shapes Present");
			}
			
		
		}
		
	public static void main (String args) {
		
      Shapes s = new Shapes();
      s.calculateShapeArea(3, 12);
      

		
		
	

	}
	 {
		
	}
	

}

