package pkgcom.cognizant.shapes;

public class Rectangle {

	void calculateArea() {
System.out.print("The Area  of the retangle is calculated using the formula length * breadth");
	}
}
