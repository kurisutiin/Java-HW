package pkgcom.cognizant.shapes;

public class Triangle  {
	
	public void calculateArea (int sides) {
		double realr = 0.433 * sides * sides;
		
		System.out.println(" The area of Triangle is " + realr);
		
		
	}

}
