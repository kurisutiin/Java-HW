package pkgcom.cognizant.shapes;

public class Square  {

	public void calculateArea (int sides) {
		//int Sides = 0;
		int realr = sides * sides;
		
		System.out.println(" The area of Square is " + realr);
	}
	
}
