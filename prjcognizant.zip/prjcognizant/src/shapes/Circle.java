package shapes;

public class Circle {
	public void calculateArea(int radius) {
		//double radius = 0d;
		//radius = 3.14 * radius * radius;
		
		
		float realr = 3.14f * radius * radius;
		System.out.println(" The Radius is " + realr);
		
		
		
	}
	
	

}

